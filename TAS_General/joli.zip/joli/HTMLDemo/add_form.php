
<style type="text/css">
#dis{
	display:none;
}
</style>


	
    
    <div id="dis">
    <!-- here message will be displayed -->
	</div>
        
 	
	 <form method='post' id='emp-SaveForm' action="#">
 
    <table class='table table-bordered'>
	
	    <tr>
            <td>HTML Id</td>
            <td><input type='text' name='html_id' class='form-control' placeholder='EX : 05' required /></td>
        </tr>
 
        <tr>
            <td>HTML Description</td>
            <td><input type='text' name='html_desc' class='form-control' placeholder='EX : WAP to find vowels in a string' required /></td>
        </tr>
 
        <tr>
            <td colspan="2">
            <button type="submit" class="btn btn-primary" name="btn-save" id="btn-save">
    		<span class="glyphicon glyphicon-plus"></span> Save this Record
			</button>  
            </td>
        </tr>
 
    </table>
</form>
     
