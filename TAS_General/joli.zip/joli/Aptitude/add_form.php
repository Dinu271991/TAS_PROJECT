
<style type="text/css">
#dis{
	display:none;
}
</style>


	
    
    <div id="dis">
    <!-- here message will be displayed -->
	</div>
        
 	
	 <form method='post' id='emp-SaveForm' action="#">
 
    <table class='table table-bordered'>
	
	    <tr>
            <td>Question Id</td>
            <td><input type='text' name='q_id' class='form-control' placeholder='EX : 12' required /></td>
        </tr>
 
        <tr>
            <td>Question Descripion</td>
            <td><input type='text' name='qdesc' class='form-control' placeholder='EX : HTTP stands for?' required /></td>
        </tr>
 
        <tr>
            <td>Option 1</td>
            <td><input type='text' name='option1' class='form-control' placeholder='EX : HyperText Transfer Protocol' required></td>
        </tr>
 
       		
		  <tr>
            <td>Option 2</td>
            <td><input type='text' name='option2' class='form-control' placeholder='EX : HyperTransform Text Protocol' required></td>
        </tr>
		
		<tr>
            <td>Option 3</td>
            <td><input type='text' name='option3' class='form-control' placeholder='EX : HyperTransfer Text Protocol' required></td>
        </tr>
		
		<tr>
            <td>Option 4</td>
            <td><input type='text' name='option4' class='form-control' placeholder='EX : HyperText Transform Protocol' required></td>
        </tr>
		
		  <tr>
            <td>Answer</td>
            <td><input type='text' name='answer' class='form-control' placeholder='EX : 1' required></td>
        </tr>
 
        <tr>
            <td colspan="2">
            <button type="submit" class="btn btn-primary" name="btn-save" id="btn-save">
    		<span class="glyphicon glyphicon-plus"></span> Save this Record
			</button>  
            </td>
        </tr>
 
    </table>
</form>
     
